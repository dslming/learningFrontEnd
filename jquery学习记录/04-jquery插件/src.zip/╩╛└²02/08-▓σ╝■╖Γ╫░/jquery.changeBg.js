/**
 * Created by Jepson on 2017/10/7.
 */
(function() {
  // 此插件功能强大,简直完美, 能修改背景颜色
  $.fn.bg = function( color ) {
    this.css('backgroundColor', color );
  };
  
})();