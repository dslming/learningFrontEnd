/**
 * Created by ruiwang on 2017/6/2.
 */
var add=require('./bar.js');
console.log(add(1,2));