/**
 * Created by ruiwang on 2017/6/2.
 */
function add(a,b){
    return a+b;
}
module.exports=add;