/**
 * Created by ruiwang on 2017/6/30.
 */
'use strict';
let breakfast = dessert => dessert;

let breakfast1 = (dessert1,drink1) => (dessert1,drink1);