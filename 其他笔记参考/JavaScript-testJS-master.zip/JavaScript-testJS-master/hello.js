/**
 * Created by ruiwang on 2017/5/11.
 */
function hello(){
    console.log("Hello World!");
}
hello();